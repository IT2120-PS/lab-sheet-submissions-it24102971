setwd("C://Users//it24102971//Desktop//It24102971")
##part1
##importing the data set
data<-read.table("DATA 4.txt",header =TRUE,sep = " ")
##Importing the data set
data<-read.table("Exercise.txt", header = TRUE, sep = " ")
#view the file in a separate window
fix(data)
## Attach the file into R. so, you can call the variables by their name 
attach(data)
## Part 2

## Part (a)
# Obtaining Box Plots
boxplot(X1, main="Box plot for Team Attendence", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2, main="Box plot for Team Salary", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X3, main="Box plot for Years", outline=TRUE, outpch=8, horizontal=TRUE)

# Obtaining Histogram
hist(X1, ylab="Frequency", xlab="Team Attendence", main="Histogram for Team Attendence")
hist(X2, ylab="Frequency", xlab="Team Salary", main="Histogram for Team Salary")
hist(X3, ylab="Frequency", xlab="Years", main="Histogram for Years")

# Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)

## Part (b)

## Mean
mean(X1)
mean(X2)
mean(X3)

## Median
median(X1)
median(X2)
median(X3)

## Standard Deviation
sd(X1)
sd(X2)
sd(X3)

summary(X1)
summary(X2)
summary(X3)

quantile(X1)

## Calling first Quartile of X1 using index value
quantile(X1)[2]


quantile(X1)


## Part (d
IQR(X1)
IQR(X2)
IQR(X3)


## Part 3
# Function to get the mode of a data set
get_mode <- function(x) {
  counts <- table(x)
  names(counts[counts == max(counts)])
}


# Obtaining the mode of a variable using the function above
get_mode(X3)

# table(X3) will give the frequency table for the variable
table(X3)

# max(counts) will give the maximum frequency in the frequency table
max(counts)

# counts == max(counts) will check whether frequencies in the frequency table equals maximum frequency
counts == max(counts)

# names returns the value and the frequency which gives "TRUE" in earlier logical function
names(counts[counts == max(counts)])

## Part 4
# Function to check the existence of outliers of a data set
get.outliers <- function(x){
  q1 <- quantile(x)[2]
  q3 <- quantile(sort(x))
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper Bound =", ub))
  print(paste("Lower Bound =", lb))
  print(paste("Outliers:", paste(sort(x[x > ub | x < lb]), collapse = ",")))
}

# Checking the outliers of a variable using the function defined above
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)

## Part 4
# Function to check the existence of outliers of a data set
get.outliers <- function(x){
  q1 <- quantile(x)
  q3 <- quantile(sort(x))
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  
  print(paste("Upper Bound =", ub))
  print(paste("Lower Bound =", lb))
  print(paste("Outliers:", paste(sort(x[x > ub | x < lb]), collapse = ",")))
}

# Checking the outliers of a variable using the function defined above
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)




##EXERCISE 5
#Import the CSV into E
branch_data <- read.csv("Exercise.txt")

#view the 1st few rows
head(branch_data)


#Question 2 - variable type
str(branch_data)

#Question 3 - Obtain a boxplot for sales
# Create a boxplot for Sales
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue",
        border = "darkblue")


# Get summary statistics
summary(branch_data$Sales_X1)

#Question 4 
#Five num summery (gives Min, 1st Qu., Median, Mean, 3rd Qu., Max)
summary(branch_data$Advertising_X2)

#Calculate IQR
IQR(branch_data$Advertising_X2)

#Question 5
#Function to detect outliers using IQR rule
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in Years variable
outliers_years <- find_outliers(branch_data$Years_X3)
outliers_years
